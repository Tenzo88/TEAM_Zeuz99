package com.asylum.membatik

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
//import com.asylum.membatik.dashboard.HomeActivity
import kotlinx.android.synthetic.main.activity_tracking.*

class TrackingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tracking)

//        btn_ke_home.setOnClickListener {
//            startActivity(Intent(this, HomeActivity::class.java))
//        }
    }
}