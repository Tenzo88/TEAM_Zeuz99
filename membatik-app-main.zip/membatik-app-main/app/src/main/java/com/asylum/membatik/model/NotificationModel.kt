package com.asylum.membatik.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class NotificationModel(val msgNotif: String): Parcelable