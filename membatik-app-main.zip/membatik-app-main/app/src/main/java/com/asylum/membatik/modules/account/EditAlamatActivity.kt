package com.asylum.membatik.modules.account

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.asylum.membatik.R

class EditAlamatActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_alamat)
    }
}